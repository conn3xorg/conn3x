param($A)
# Copyright (c) The Conn3x Authors
# SPDX-License-Identifier: MPL-2.0
#include safepath
#include ad
$missing = Test-ADFolders @($A.database_path, $A.log_path, $A.sysvol_path)
if (-not (Get-Module -ListAvailable -Name ADDSDeployment)) {
  throw 'AD DS is not installed. Add a windows_feature step for AD-Domain-Services with include_management_tools = true'
}
Import-Module ADDSDeployment
New-ADFolders $missing
# Both passwords become SecureStrings through .NET, as in apply_ad_forest.ps1.
# A key login has no credentials of its own to reach the forest with, so the
# account to promote with is given explicitly.
$set = @{
  NewDomainName                 = [string]$A.label
  ParentDomainName              = [string]$A.parent
  DomainType                    = $(if ($A.tree) { 'TreeDomain' } else { 'ChildDomain' })
  Credential                    = [Management.Automation.PSCredential]::new([string]$A.username, [Net.NetworkCredential]::new('', [string]$A.password).SecurePassword)
  SafeModeAdministratorPassword = [Net.NetworkCredential]::new('', [string]$A.safe_mode_password).SecurePassword
}
if ($A.netbios_name) { $set.NewDomainNetbiosName = [string]$A.netbios_name }
if ($A.database_path) { $set.DatabasePath = [string]$A.database_path }
if ($A.log_path) { $set.LogPath = [string]$A.log_path }
if ($A.sysvol_path) { $set.SysvolPath = [string]$A.sysvol_path }
# A child's parent DNS gets a delegation to this server, so names in the new
# domain resolve from the rest of the forest. A tree has no parent zone to
# delegate from. Never a reboot: that's its own step, so it shows in the plan.
$r = Install-ADDSDomain @set -InstallDns -CreateDnsDelegation:(-not $A.tree) -NoRebootOnCompletion -Force -Confirm:$false -WarningAction SilentlyContinue
if ([string]$r.Status -ne 'Success') { throw "Install-ADDSDomain: $($r.Status): $($r.Message)" }
Set-RebootMarker ([string]$A.domain_name)
@{ restart = $true }
